function imgout=image_enchance_process(img)

imgout=image_enc_filter(img);


